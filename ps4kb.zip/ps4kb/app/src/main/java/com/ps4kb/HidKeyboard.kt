package com.ps4kb

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import java.util.concurrent.Executors

/**
 * يجعل الهاتف يظهر ككيبورد بلوتوث (HID) باستخدام BluetoothHidDevice (أندرويد 9+).
 */
@SuppressLint("MissingPermission")
class HidKeyboard(
    private val context: Context,
    private val onState: (String) -> Unit
) {
    private val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val callbackExecutor = Executors.newSingleThreadExecutor()
    private val sendExecutor = Executors.newSingleThreadExecutor()

    private var hid: BluetoothHidDevice? = null
    @Volatile private var host: BluetoothDevice? = null

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            onState(if (registered) "جاهز. اقترن من الـ PS4 أو اختر جهازاً من القائمة" else "غير مسجل")
        }

        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    host = device
                    onState("متصل بـ ${device.name ?: device.address}")
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    if (host == device) host = null
                    onState("غير متصل")
                }
            }
        }
    }

    fun start() {
        adapter.getProfileProxy(context, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                if (profile != BluetoothProfile.HID_DEVICE) return
                val device = proxy as BluetoothHidDevice
                hid = device
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "PS4 Keyboard",
                    "Phone keyboard",
                    "ps4kb",
                    BluetoothHidDevice.SUBCLASS1_KEYBOARD,
                    DESCRIPTOR
                )
                device.registerApp(sdp, null, null, callbackExecutor, callback)
            }

            override fun onServiceDisconnected(profile: Int) {
                hid = null
                onState("انقطعت خدمة HID")
            }
        }, BluetoothProfile.HID_DEVICE)
    }

    fun stop() {
        try {
            hid?.unregisterApp()
        } catch (_: Exception) {
        }
        hid = null
        host = null
    }

    fun connect(device: BluetoothDevice) {
        hid?.connect(device)
    }

    val isConnected: Boolean get() = host != null

    /** ضغطة مفتاح واحدة ثم تركه. */
    fun tap(modifier: Int, keyCode: Int) {
        sendExecutor.execute {
            val h = hid ?: return@execute
            val d = host ?: return@execute
            h.sendReport(d, 0, byteArrayOf(modifier.toByte(), 0, keyCode.toByte(), 0, 0, 0, 0, 0))
            Thread.sleep(15)
            h.sendReport(d, 0, ByteArray(8))
            Thread.sleep(15)
        }
    }

    /** كتابة نص بحروف US QWERTY. الحروف غير المدعومة (مثل العربية) تُتجاهل. */
    fun typeText(text: String) {
        for (c in text) {
            val pair = charToHid(c) ?: continue
            tap(pair.first, pair.second)
        }
    }

    companion object {
        const val SHIFT = 0x02

        const val KEY_ENTER = 0x28
        const val KEY_ESC = 0x29
        const val KEY_BACKSPACE = 0x2A
        const val KEY_TAB = 0x2B
        const val KEY_DELETE = 0x4C
        const val KEY_RIGHT = 0x4F
        const val KEY_LEFT = 0x50
        const val KEY_DOWN = 0x51
        const val KEY_UP = 0x52

        private const val SYM_PLAIN = "-=[]\\;'`,./"
        private val SYM_PLAIN_KEYS = intArrayOf(0x2D, 0x2E, 0x2F, 0x30, 0x31, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38)
        private const val SYM_SHIFT = "_+{}|:\"~<>?"
        private const val NUM_SHIFT = "!@#$%^&*()"

        fun charToHid(c: Char): Pair<Int, Int>? {
            return when {
                c in 'a'..'z' -> Pair(0, 0x04 + (c - 'a'))
                c in 'A'..'Z' -> Pair(SHIFT, 0x04 + (c - 'A'))
                c in '1'..'9' -> Pair(0, 0x1E + (c - '1'))
                c == '0' -> Pair(0, 0x27)
                c == ' ' -> Pair(0, 0x2C)
                c == '\n' -> Pair(0, KEY_ENTER)
                c == '\t' -> Pair(0, KEY_TAB)
                SYM_PLAIN.indexOf(c) >= 0 -> Pair(0, SYM_PLAIN_KEYS[SYM_PLAIN.indexOf(c)])
                SYM_SHIFT.indexOf(c) >= 0 -> Pair(SHIFT, SYM_PLAIN_KEYS[SYM_SHIFT.indexOf(c)])
                NUM_SHIFT.indexOf(c) >= 0 -> {
                    val i = NUM_SHIFT.indexOf(c)
                    Pair(SHIFT, if (i == 9) 0x27 else 0x1E + i)
                }
                else -> null
            }
        }

        // Boot keyboard: 1 byte modifiers, 1 byte reserved, 6 bytes keys. (بدون Report ID)
        private val DESCRIPTOR = byteArrayOf(
            0x05, 0x01, 0x09, 0x06, 0xA1.toByte(), 0x01,
            0x05, 0x07, 0x19, 0xE0.toByte(), 0x29, 0xE7.toByte(),
            0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95.toByte(), 0x08, 0x81.toByte(), 0x02,
            0x95.toByte(), 0x01, 0x75, 0x08, 0x81.toByte(), 0x01,
            0x95.toByte(), 0x05, 0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x91.toByte(), 0x02,
            0x95.toByte(), 0x01, 0x75, 0x03, 0x91.toByte(), 0x01,
            0x95.toByte(), 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65,
            0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81.toByte(), 0x00,
            0xC0.toByte()
        )
    }
}
