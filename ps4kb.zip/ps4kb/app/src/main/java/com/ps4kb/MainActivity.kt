package com.ps4kb

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView

@SuppressLint("MissingPermission")
class MainActivity : Activity() {

    private lateinit var keyboard: HidKeyboard
    private lateinit var status: TextView
    private lateinit var deviceList: ListView
    private lateinit var input: EditText
    private var devices: List<BluetoothDevice> = emptyList()
    private var started = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        keyboard = HidKeyboard(this) { msg -> runOnUiThread { status.text = msg } }

        if (Build.VERSION.SDK_INT >= 31 && !hasBtPermissions()) {
            requestPermissions(
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE),
                1
            )
        } else {
            startKeyboard()
        }
    }

    private fun hasBtPermissions(): Boolean {
        return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasBtPermissions()) startKeyboard() else status.text = "الصلاحيات مطلوبة للعمل"
    }

    private fun startKeyboard() {
        if (started) return
        started = true
        keyboard.start()
        refreshDevices()
    }

    private fun refreshDevices() {
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        devices = adapter?.bondedDevices?.toList() ?: emptyList()
        deviceList.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            devices.map { it.name ?: it.address }
        )
    }

    private fun buildUi() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        status = TextView(this).apply {
            text = "جاري التهيئة..."
            textSize = 16f
            gravity = Gravity.CENTER
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "اجعل الهاتف مرئياً للـ PS4"
            setOnClickListener {
                val i = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
                startActivity(i)
            }
        })

        root.addView(TextView(this).apply {
            text = "الأجهزة المقترنة (اضغط للاتصال):"
            setPadding(0, pad / 2, 0, 0)
        })
        deviceList = ListView(this)
        deviceList.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            (150 * resources.displayMetrics.density).toInt()
        )
        deviceList.setOnItemClickListener { _, _, pos, _ ->
            devices.getOrNull(pos)?.let { keyboard.connect(it) }
        }
        root.addView(deviceList)
        root.addView(Button(this).apply {
            text = "تحديث القائمة"
            setOnClickListener { refreshDevices() }
        })

        input = EditText(this).apply {
            hint = "اكتب هنا ثم اضغط إرسال"
            minLines = 2
        }
        root.addView(input)
        root.addView(Button(this).apply {
            text = "إرسال النص"
            setOnClickListener {
                keyboard.typeText(input.text.toString())
                input.setText("")
            }
        })

        root.addView(keyRow(
            "Enter" to HidKeyboard.KEY_ENTER,
            "Esc" to HidKeyboard.KEY_ESC,
            "⌫" to HidKeyboard.KEY_BACKSPACE,
            "Tab" to HidKeyboard.KEY_TAB
        ))
        root.addView(keyRow(
            "←" to HidKeyboard.KEY_LEFT,
            "↑" to HidKeyboard.KEY_UP,
            "↓" to HidKeyboard.KEY_DOWN,
            "→" to HidKeyboard.KEY_RIGHT
        ))

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun keyRow(vararg keys: Pair<String, Int>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((label, code) in keys) {
            row.addView(Button(this).apply {
                text = label
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { keyboard.tap(0, code) }
            })
        }
        return row
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::keyboard.isInitialized) keyboard.stop()
    }
}
